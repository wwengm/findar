Financial Datareader provides data solutions to quantitative trading and       backtesting.Currently provides up-to-date index constituent lists, full ETF lists       trading boardlots, fundamental informations, Libor rates etc, for both US and HK market.


